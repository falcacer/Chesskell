module Main (main) where

import Parse
import Common

main :: IO ()
main = do
    let input = "WKe8-e7;LRh8-h7"
    case parseMoves input of
        Left err -> putStrLn $ "Error: " ++ show err
        Right moves -> print moves
