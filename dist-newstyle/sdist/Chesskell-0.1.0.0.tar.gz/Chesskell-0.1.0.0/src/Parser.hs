module Parser 
    ( parseMoves
    ) where

import Text.Parsec
import Text.Parsec.String
import Common

positionParser :: Parser Position
positionParser = do
    col <- oneOf "abcdefgh"
    row <- oneOf "12345678"
    return $ Pos col (read [row])

colorAndPieceParser :: Parser (Color, PieceName)
colorAndPieceParser = do
    colorChar <- oneOf "WL"
    pieceChar <- oneOf "KQRBNP"
    case (charToColor colorChar, charToPieceName pieceChar) of
        (Just color, Just piece) -> return (color, piece)
        _ -> fail "Invalid color or piece"

moveParser :: Parser Move
moveParser = do
    (color, pieceName) <- colorAndPieceParser
    startPos <- positionParser
    char '-'
    endPos <- positionParser
    let pieceInfo = Info color 0 startPos  -- Using 0 as default piece ID
    return $ Move (MkPiece pieceName pieceInfo) Normal endPos

movesParser :: Parser [Move]
movesParser = moveParser `sepBy` char ';'

-- Main parsing function
parseMoves :: String -> Either ParseError [Move]
parseMoves = parse movesParser "chess moves"
