module Common 
    ( Position(..)
    , Color(..)
    , PieceName(..)
    , PieceInfo(..)
    , Piece(..)
    , Column(..)
    , Row(..)
    , MoveType(..)
    , Move(..)
    , charToColor
    , charToPieceName
    ) where

    data Position = Pos Char Int deriving (Show)

    data Color = White | Black deriving (Show)

    data PieceName = King | Queen | Rook | Bishop | Knight | Pawn deriving (Show)

    data PieceInfo = Info Color Int Position deriving (Show)

    data Piece = MkPiece PieceName PieceInfo deriving (Show)

    data Column = A | B | C | D | E | F | G | H deriving (Show)

    data Row = One | Two | Three | Four | Five | Six | Seven | Eight deriving (Show)
    
    data MoveType = Normal | Capture deriving (Show)

    data Move = Move Piece MoveType Position deriving (Show)

    charToColor :: Char -> Maybe Color
    charToColor 'W' = Just White
    charToColor 'L' = Just Black
    charToColor _ = Nothing

    charToPieceName :: Char -> Maybe PieceName
    charToPieceName 'K' = Just King
    charToPieceName 'Q' = Just Queen
    charToPieceName 'R' = Just Rook
    charToPieceName 'B' = Just Bishop
    charToPieceName 'N' = Just Knight
    charToPieceName 'P' = Just Pawn
    charToPieceName _ = Nothing
